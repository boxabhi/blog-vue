alert("GELLO");

console.log("HEY")